package com.example.final_module.service.customer.impl;


import com.example.final_module.model.KhuyenMai;
import com.example.final_module.repository.customer.KhuyenMaiRepository;
import com.example.final_module.service.customer.KhuyenMaiService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class KhuyenMaiServiceImpl implements KhuyenMaiService {
    @Autowired
    KhuyenMaiRepository khuyenMaiRepository;


    @Override
    public List<KhuyenMai> findAll() {
        return khuyenMaiRepository.findAll();
    }

    @Override
    public Page<KhuyenMai> findAll(Pageable pageable) {
        return khuyenMaiRepository.findAll(pageable);
    }

    @Override
    public void save(KhuyenMai khuyenMai) {
        khuyenMaiRepository.save(khuyenMai);
    }

    @Override
    public KhuyenMai findById(int id) {
        return khuyenMaiRepository.findById(id).orElse(null);
    }

    @Override
    public void delete(Integer id) {
        khuyenMaiRepository.deleteById(id);
    }

//    @Override
//    public Page<Customer> findByCustomerType(Integer customerType, Pageable pageable) {
//        return customerRepository.findByCustomerType_CustomerTypeId(customerType, pageable);
//    }
//
//    @Override
//    public Page<Customer> findByCustomerName(String customerName, Pageable pageable) {
//        return customerRepository.findByCustomerNameContaining(customerName, pageable);
//    }
}
