package com.example.final_module.repository.customer;


import com.example.final_module.model.KhuyenMai;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface KhuyenMaiRepository extends JpaRepository<KhuyenMai, Integer> {
//    Page<KhuyenMai> findByCustomerType_CustomerTypeId(Integer customerType, Pageable pageable);
//    Page<KhuyenMai> findByCustomerNameContaining(String customerName, Pageable pageable);
}
