package com.example.final_module.service.customer;


import com.example.final_module.model.KhuyenMai;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface KhuyenMaiService {
    List<KhuyenMai> findAll();

    Page<KhuyenMai> findAll(Pageable pageable);

    void save(KhuyenMai customer);

    KhuyenMai findById(int id);

    void delete(Integer id);

//    Page<Customer> findByCustomerType(Integer customerType, Pageable pageable);
//    Page<Customer> findByCustomerName(String customerName, Pageable pageable);
}
